# 实验事实摘要（可贴回讨论）



问题：Directory-only engineering parity: toy and certified Behnke1

身份：1c2624ab29a5240d282a8f68b34d55064c532120b101bf3438582519bccf2686

类型/范围/seed：fixed / ten_h / 17

状态：completed；完整=True；身份=matched

原定预算：{"logical_generation": 0, "manual_or_P0_evaluations": 2, "API_attempts": 0, "max_program_instances": 4, "max_solve_passes": 8}

已用预算：{"committed_tasks": 2, "reserved_tasks": 2, "logical_generation": 0, "API_attempts": 0, "complete_responses": 0, "certified_strategies": 2, "certified_new_generation": 0, "failed_or_uncommitted_tasks": 0, "AST_duplicates": 0, "cache_hits": 0, "new_program_instances_reserved": 4, "first_starts": 4, "recheck_starts": 4}

初始冠军：None

新增生成冠军：None

已见最好：{'id': 'equal', 'stage': 'fixed', 'condition': None, 'status': 'completed', 'fitness': -1.2976190476190477, 'valid': True, 'repeat': 0, 'pair_index': None, 'failure': None, 'AST_duplicate': False, 'cache_hit': False, 'parents': '[]', 'error_type': None, 'successful_rows': 2}

新增−初始Fitness：None

逐方法预算/结果：[{'method': 'fixed', 'search_seed': 17, 'planned_new_slots': 0, 'used_new_slots': 0, 'API_attempts': 0, 'complete_responses': 0, 'certified_new': 0, 'mean_valid_new': None}]

固定配对差值：None

API/用量：{'known_input_tokens': 0, 'known_output_tokens': 0, 'unknown_usage_attempts': 0, 'verified_currency_cost': 0, 'platform_points': None, 'note': 'No fee gate or invoice/account queries; mock tokens are zero, not real generation.'}

评价区间秒：0.9805637090175878

限制：Facts only; no generated scientific interpretation.；Complete Fitness requires all frozen instances; failures never get prefix mean.；P0 evaluations cost separately; cache hits still occupy logical slots.；This run is not automatically budget-fair with historical B1/B2.

结果：/Users/DDXQL/Developer/FJSP-Heuristic-Research-h-usage-space/runs/multi-problem-layout-regression-20261027-v1/results

事实不自动解释为方法有效或无效。
