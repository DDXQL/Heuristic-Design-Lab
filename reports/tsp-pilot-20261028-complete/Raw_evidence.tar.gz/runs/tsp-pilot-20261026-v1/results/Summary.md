# TSP固定预算迁移小试

状态：paused；模式：real

预算：{"logical": 10, "API_attempts": 10, "complete_responses": 10, "unknown_attempts": 0}

逐阶段：

[
  {
    "stage": "manual-H",
    "planned_new": 0,
    "used_new": 0,
    "API_attempts": 0,
    "complete_responses": 0,
    "certified_new": 0,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9900181489498406,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 5
  },
  {
    "stage": "H",
    "planned_new": 10,
    "used_new": 10,
    "API_attempts": 10,
    "complete_responses": 10,
    "certified_new": 0,
    "failed_or_uncommitted_new": 10,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": null,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 0
  }
]

冻结确认/迁移：

{}

成本：{"known_input_tokens": 22550, "known_output_tokens": 15398, "unknown_usage_attempts": 0, "platform_points": null, "verified_currency_cost": null}

限制：2 repeats per method; migration pilot, not stable superiority evidence；static/P0 costs reported separately；NN-relative metric, not optimality gap；confirmation and transfer are separate evaluations
