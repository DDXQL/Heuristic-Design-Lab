# TSP固定预算迁移小试

状态：completed；模式：real

预算：{"logical": 50, "API_attempts": 50, "complete_responses": 50, "unknown_attempts": 0}

逐阶段：

[
  {
    "stage": "manual-H",
    "planned_new": 0,
    "used_new": 0,
    "API_attempts": 0,
    "complete_responses": 0,
    "certified_new": 0,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9900181489498406,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 5
  },
  {
    "stage": "H",
    "planned_new": 10,
    "used_new": 10,
    "API_attempts": 10,
    "complete_responses": 10,
    "certified_new": 10,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -1.139248862320581,
    "new_champion": -1.139248862320581,
    "phase": "completed",
    "physical_evaluations": 10
  },
  {
    "stage": "static",
    "planned_new": 0,
    "used_new": 0,
    "API_attempts": 0,
    "complete_responses": 0,
    "certified_new": 0,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9767105276580079,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 15
  },
  {
    "stage": "IND_701",
    "planned_new": 10,
    "used_new": 10,
    "API_attempts": 10,
    "complete_responses": 10,
    "certified_new": 10,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 1,
    "best_fitness": -0.9767105276580079,
    "new_champion": -0.9857598779560671,
    "phase": "completed",
    "physical_evaluations": 14
  },
  {
    "stage": "IND_702",
    "planned_new": 10,
    "used_new": 10,
    "API_attempts": 10,
    "complete_responses": 10,
    "certified_new": 10,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9767105276580079,
    "new_champion": -0.9784588353554342,
    "phase": "completed",
    "physical_evaluations": 15
  },
  {
    "stage": "EVO_801",
    "planned_new": 10,
    "used_new": 10,
    "API_attempts": 10,
    "complete_responses": 10,
    "certified_new": 10,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9729656391966077,
    "new_champion": -0.9729656391966077,
    "phase": "completed",
    "physical_evaluations": 15
  },
  {
    "stage": "EVO_802",
    "planned_new": 10,
    "used_new": 10,
    "API_attempts": 10,
    "complete_responses": 10,
    "certified_new": 10,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9767105276580079,
    "new_champion": -0.9776141691891469,
    "phase": "completed",
    "physical_evaluations": 15
  },
  {
    "stage": "validation",
    "planned_new": 0,
    "used_new": 0,
    "API_attempts": 0,
    "complete_responses": 0,
    "certified_new": 0,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9590634896572261,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 2
  },
  {
    "stage": "confirmation",
    "planned_new": 0,
    "used_new": 0,
    "API_attempts": 0,
    "complete_responses": 0,
    "certified_new": 0,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9880261119562419,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 1
  },
  {
    "stage": "transfer",
    "planned_new": 0,
    "used_new": 0,
    "API_attempts": 0,
    "complete_responses": 0,
    "certified_new": 0,
    "failed_or_uncommitted_new": 0,
    "unknown_API_attempts": 0,
    "duplicates": 0,
    "best_fitness": -0.9932904866482446,
    "new_champion": null,
    "phase": "completed",
    "physical_evaluations": 1
  }
]

冻结确认/迁移：

{
  "confirmation": {
    "instances": 20,
    "final_total_length": 134.10470488851414,
    "static_total_length": 134.10470488851414,
    "final_fitness": -0.9880261119562419,
    "static_fitness": -0.9880261119562419,
    "wins": 0,
    "losses": 0,
    "ties": 20,
    "deltas": {
      "confirmation_000.json": 0.0,
      "confirmation_001.json": 0.0,
      "confirmation_002.json": 0.0,
      "confirmation_003.json": 0.0,
      "confirmation_004.json": 0.0,
      "confirmation_005.json": 0.0,
      "confirmation_006.json": 0.0,
      "confirmation_007.json": 0.0,
      "confirmation_008.json": 0.0,
      "confirmation_009.json": 0.0,
      "confirmation_010.json": 0.0,
      "confirmation_011.json": 0.0,
      "confirmation_012.json": 0.0,
      "confirmation_013.json": 0.0,
      "confirmation_014.json": 0.0,
      "confirmation_015.json": 0.0,
      "confirmation_016.json": 0.0,
      "confirmation_017.json": 0.0,
      "confirmation_018.json": 0.0,
      "confirmation_019.json": 0.0
    }
  },
  "transfer": {
    "instances": 10,
    "final_total_length": 95.51648311557452,
    "static_total_length": 95.51648311557452,
    "final_fitness": -0.9932904866482446,
    "static_fitness": -0.9932904866482446,
    "wins": 0,
    "losses": 0,
    "ties": 10,
    "deltas": {
      "transfer_000.json": 0.0,
      "transfer_001.json": 0.0,
      "transfer_002.json": 0.0,
      "transfer_003.json": 0.0,
      "transfer_004.json": 0.0,
      "transfer_005.json": 0.0,
      "transfer_006.json": 0.0,
      "transfer_007.json": 0.0,
      "transfer_008.json": 0.0,
      "transfer_009.json": 0.0
    }
  }
}

成本：{"known_input_tokens": 239635, "known_output_tokens": 23086, "unknown_usage_attempts": 0, "platform_points": null, "verified_currency_cost": null}

限制：2 repeats per method; migration pilot, not stable superiority evidence；static/P0 costs reported separately；NN-relative metric, not optimality gap；confirmation and transfer are separate evaluations
