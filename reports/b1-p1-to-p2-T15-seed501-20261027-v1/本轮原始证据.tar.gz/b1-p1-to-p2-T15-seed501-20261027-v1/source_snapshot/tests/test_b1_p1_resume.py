"""P1 migration and generation-two acceptance. Synthetic fitness, no solves/API."""
from copy import deepcopy
from dataclasses import replace
import random
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from fjsp_usage.research.events import atomic_json
from fjsp_usage.research.evolution import select_parents, _tuple_tree
from fjsp_usage.research.protocol import digest
from tools import b1_p1_resume as resume
from test_b1_nonstream_local import Inner


class P1ResumeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)
        old = Path(os.environ.get('B1_RESUME_TEST_ORIGIN',resume.ROOT/'runs'/resume.ORIGIN_NAME))
        self.c = resume.read(old/'r501/B/checkpoint.json')
        self.j = resume.read(old/'r501/B/batch_requests.json')
        self.p = resume.read(old/'Protocol.json')
        base = resume.legacy.ns.Config.from_dict(self.p['config'])
        self.config = replace(base,mode='synthetic',provider=replace(base.provider,
            endpoint='http://localhost/mock',api_key_env=None))
        self.inner = Inner(self.config)
        self.profile = resume.legacy.ns.CompleteNonstreamTransport(self.inner,self.path/'received')
        self.transport = resume.legacy.ns.TimedRecorder(self.profile,self.path/'wire')
        self.target = self.path/'r501/B'

    def bundle(self):
        return resume.migrate(self.c,self.j,self.config,self.transport.identity,'MOCK-CONTEXT',
            self.target,self.p['H_order'],self.p['request_phase'])

    def test_migration_keeps_all_science_rng_and_old_budget(self):
        b = self.bundle(); c = deepcopy(b['checkpoint.json']); c['signature']=self.c['signature']
        self.assertEqual(c,self.c)
        j = deepcopy(b['batch_requests.json']); j['identity']=self.j['identity'];j.pop('recovery_source_P1')
        self.assertEqual(j,self.j)
        self.assertEqual(len(b['batch_requests.json']['requests']),19)

    def test_unknown_boundary_does_not_migrate(self):
        for field,value in [('inflight',{'id':'UNKNOWN'}),('generation',0),('cursor',1),('children',[{}])]:
            c=deepcopy(self.c);c[field]=value
            with self.assertRaises(ValueError):
                resume.migrate(c,self.j,self.config,'T','C',self.target,self.p['H_order'],self.p['request_phase'])

    def test_ten_synthetic_slots_preserve_first_parent_rng_and_survival(self):
        # Full byte-preservation is tested above. Keep this synthetic execution
        # test small instead of serializing historical action traces every slot.
        for cache in self.c['evaluations'].values():
            r=cache['result']
            if r.get('valid'):
                cache['result']={'valid':True,'total_instances':21,'fitness':r['fitness'],
                    'instances':[{'file':n,'score':r['fitness']} for n in self.p['train_names']]}
            else:
                cache['result']={'valid':False,'total_instances':21,'fitness':None,'instances':[]}
        bundle=self.bundle()
        for k,v in bundle.items():atomic_json(self.target/k,v)
        atomic_json(self.path/'Protocol.json',{'MOCK':True})
        evaluated=[]
        def evaluate(c):
            evaluated.append(c.key)
            return {'valid':True,'total_instances':21,'fitness':-2.0,
                'instances':[{'file':n,'score':-2.0,'lower_bound':10,'makespan':20}
                    for n in self.p['train_names']]}
        # Hard traps: this test must never contact a provider or scheduler.
        with patch('socket.socket.connect',side_effect=AssertionError('NO NETWORK')), \
             patch('fjsp_usage.research_real.runtime.evaluate',side_effect=AssertionError('NO SOLVE')), \
             patch.object(resume,'check_live',return_value=None):
            e=resume.ResumeSearch(self.target,experiment=self.config,training_names=self.p['train_names'],
                arm='B',config=self.config.u_search(501),members=[resume.checked_candidate(x['candidate'],'h')
                    for x in resume.read(Path(self.config.fixed_h_source['directory'])/'H_frozen.json')['members']],
                evaluator=evaluate,transport=self.transport,context='MOCK-CONTEXT')
            e.resume_protocol={}
            rng=random.Random();rng.setstate(_tuple_tree(self.c['rng']))
            parents=select_parents(self.c['population'],2,rng)
            e.run()
            self.assertEqual(e.state['phase'],'completed')
            self.assertEqual(e.state['generation'],2)
            self.assertEqual(len(e.state['attempts']),29)
            self.assertEqual(len(self.inner.sent),10)
            self.assertEqual(len(e.ledger.data['api_attempts']),29)
            new=e.state['attempts'][19:]
            self.assertEqual(new[0]['parents'],[r['id'] for r in parents])
            self.assertEqual([a['operator'] for a in new],['CROSS']*5+['MUTATE']*5)
            self.assertTrue(all(a['id']==f'B/g0001/{i:06d}' for i,a in enumerate(new)))
            self.assertEqual(e.state['population_snapshots']['P1'],[
                {k:r[k] for k in ('id','fitness','candidate')} for r in self.c['population']])


if __name__=='__main__':unittest.main()
